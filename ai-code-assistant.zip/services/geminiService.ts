

import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, Tip } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export type Action = 'analyze' | 'debug' | 'explain';

const tipSchema = {
    type: Type.OBJECT,
    properties: {
        text: { type: Type.STRING, description: "A detailed tip or explanation." },
        simplified: { type: Type.STRING, description: "The same tip, but simplified for a beginner." }
    },
    required: ["text", "simplified"]
};

const codeVersionSchema = {
    type: Type.OBJECT,
    properties: {
        code: { type: Type.STRING },
        tips: { type: Type.ARRAY, items: tipSchema }
    },
    required: ["code", "tips"]
};

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        cleanCode: { ...codeVersionSchema, description: "Code refactored for readability." },
        performantCode: { ...codeVersionSchema, description: "Code refactored for performance." },
        advancedCode: { ...codeVersionSchema, description: "Code refactored using advanced techniques." },
        complexity: {
            type: Type.OBJECT,
            properties: {
                original: { type: Type.STRING, description: "Complexity analysis of the original code." },
                refactored: { type: Type.STRING, description: "Complexity analysis of the refactored code." }
            },
            required: ["original", "refactored"]
        }
    },
    required: ["cleanCode", "performantCode", "advancedCode", "complexity"]
};

const debugSchema = {
    type: Type.OBJECT,
    properties: {
        fixedCode: { ...codeVersionSchema, description: "The corrected code with explanations of the fixes." }
    },
    required: ["fixedCode"]
};

const explanationSchema = {
    type: Type.OBJECT,
    properties: {
        explanation: {
            type: Type.OBJECT,
            properties: {
                tips: { type: Type.ARRAY, items: tipSchema, description: "A list of explanations for the code." }
            },
            required: ["tips"]
        }
    },
    required: ["explanation"]
};

const getPromptAndSchema = (code: string, language: string, action: Action) => {
    const baseIntro = `You are an expert senior software engineer specializing in ${language}. Analyze the following ${language} code snippet provided by the user. Your entire response must be a single, valid JSON object matching the specified schema. Do not include any markdown formatting.`;

    const userCodeBlock = `User's Code:\n\`\`\`${language}\n${code}\n\`\`\``;

    switch (action) {
        case 'debug':
            return {
                prompt: `${baseIntro}\nYour task is to act as a code debugger. Identify any bugs, errors, or anti-patterns in the code. Provide a corrected version of the code and a list of tips. Each tip should explain a specific fix and why it was necessary. For each tip, also provide a simplified version for beginners.\n\n${userCodeBlock}`,
                schema: debugSchema
            };
        case 'explain':
            return {
                prompt: `${baseIntro}\nYour task is to explain the code in a clear and concise way. Break down the code's functionality, logic, and purpose into a series of explanatory tips. For each tip, also provide a simplified version for beginners.\n\n${userCodeBlock}`,
                schema: explanationSchema
            };
        case 'analyze':
        default:
            return {
                prompt: `${baseIntro}\nYour task is to refactor the code into three distinct versions (Clean, Performant, Advanced), provide explanatory tips for each (with a simplified version for beginners), and generate a code complexity analysis.\n\n${userCodeBlock}`,
                schema: analysisSchema
            };
    }
};

export const processCode = async (code: string, language: string, action: Action): Promise<AnalysisResult> => {
    const { prompt, schema } = getPromptAndSchema(code, language, action);

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: schema,
                temperature: 0.3,
            },
        });

        const jsonString = response.text.trim();
        const rawResult = JSON.parse(jsonString);

        // Map the raw result to the unified AnalysisResult type
        switch (action) {
            case 'debug':
                return {
                    type: 'debug',
                    title: 'Debugging Result',
                    cleanCode: rawResult.fixedCode,
                };
            case 'explain':
                return {
                    type: 'explanation',
                    title: 'Code Explanation',
                    cleanCode: { code: code, tips: rawResult.explanation.tips },
                };
            case 'analyze':
            default:
                return {
                    type: 'analysis',
                    ...rawResult,
                };
        }
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get analysis from Gemini API.");
    }
};