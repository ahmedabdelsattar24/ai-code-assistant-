

import React from 'react';
import { SparklesIcon, BugIcon, QuestionIcon } from './Icons';
import { Action } from '../services/geminiService';

interface CodeInputProps {
    code: string;
    setCode: (code: string) => void;
    language: string;
    setLanguage: (lang: string) => void;
    onProcess: (action: Action) => void;
    loadingAction: Action | null;
}

const languages = ['python', 'javascript', 'typescript', 'java', 'go', 'rust', 'csharp'];

const ActionButton: React.FC<{
    action: Action;
    label: string;
    icon: React.ReactNode;
    onClick: () => void;
    loadingAction: Action | null;
}> = ({ action, label, icon, onClick, loadingAction }) => {
    const isLoading = loadingAction === action;
    return (
        <button
            onClick={onClick}
            disabled={!!loadingAction}
            className={`w-full flex items-center justify-center p-3 font-semibold rounded-lg shadow-md transition-all duration-200 ease-in-out transform hover:scale-105
            ${action === 'analyze' && 'bg-indigo-600 hover:bg-indigo-700 text-white'}
            ${action === 'debug' && 'bg-amber-500 hover:bg-amber-600 text-white'}
            ${action === 'explain' && 'bg-teal-500 hover:bg-teal-600 text-white'}
            disabled:bg-gray-400 disabled:cursor-not-allowed disabled:scale-100`}
        >
            {icon}
            {isLoading ? 'Processing...' : label}
        </button>
    );
};

export const CodeInput: React.FC<CodeInputProps> = ({ code, setCode, language, setLanguage, onProcess, loadingAction }) => {
    return (
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-3">
                    <label htmlFor="code-input" className="block text-sm font-medium text-gray-600 mb-1">
                        Your Code Snippet
                    </label>
                    <textarea
                        id="code-input"
                        value={code}
                        onChange={(e) => setCode(e.target.value)}
                        placeholder="Paste your code here..."
                        className="w-full h-72 p-4 font-mono text-sm bg-gray-800 text-gray-100 placeholder-gray-400 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out"
                        spellCheck="false"
                    />
                </div>
                <div className="md:col-span-1 flex flex-col space-y-4">
                    <div>
                        <label htmlFor="language-select" className="block text-sm font-medium text-gray-600 mb-1">
                            Language
                        </label>
                        <select
                            id="language-select"
                            value={language}
                            onChange={(e) => setLanguage(e.target.value)}
                            className="w-full p-2.5 bg-gray-800 text-gray-100 border border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 ease-in-out"
                        >
                            {languages.map((lang) => (
                                <option key={lang} value={lang} className="bg-gray-800 text-gray-100">
                                    {lang.charAt(0).toUpperCase() + lang.slice(1)}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="flex flex-col space-y-3">
                        <ActionButton 
                           action="analyze"
                           label="Analyze Code"
                           icon={<SparklesIcon className="h-5 w-5 mr-2" />}
                           onClick={() => onProcess('analyze')}
                           loadingAction={loadingAction}
                        />
                         <ActionButton 
                           action="debug"
                           label="Debug Code"
                           icon={<BugIcon className="h-5 w-5 mr-2" />}
                           onClick={() => onProcess('debug')}
                           loadingAction={loadingAction}
                        />
                         <ActionButton 
                           action="explain"
                           label="Explain Code"
                           icon={<QuestionIcon className="h-5 w-5 mr-2" />}
                           onClick={() => onProcess('explain')}
                           loadingAction={loadingAction}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};