import React from 'react';
import { BotIcon } from './Icons';

export const Header: React.FC = () => (
    <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="container mx-auto p-4 flex items-center justify-center space-x-3">
            <BotIcon className="h-8 w-8 text-indigo-500" />
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
                AI Code Assistant
            </h1>
        </div>
    </header>
);