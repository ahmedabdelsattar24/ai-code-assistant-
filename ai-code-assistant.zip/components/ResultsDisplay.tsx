

import React, { useState, useEffect } from 'react';
import { AnalysisResult, Tab, CodeVersion, Tip } from '../types';
import { CopyIcon, CheckIcon, LightbulbIcon, InfoIcon } from './Icons';

interface ResultsDisplayProps {
    result: AnalysisResult;
    originalCode: { code: string; language: string; };
}

const highlightComments = (code: string, language: string): React.ReactNode => {
    let commentRegex: RegExp;
    switch (language) {
        case 'python':
            commentRegex = /(#.*)/g;
            break;
        case 'javascript':
        case 'typescript':
        case 'java':
        case 'go':
        case 'rust':
        case 'csharp':
        default:
            // This regex handles both // and /* */ comments
            commentRegex = /(\/\/.*)|(\/\*[\s\S]*?\*\/)/g;
            break;
    }

    const parts: React.ReactNode[] = [];
    let lastIndex = 0;
    let match;

    while ((match = commentRegex.exec(code)) !== null) {
        // Add the text before the comment
        if (match.index > lastIndex) {
            parts.push(<span key={`code-${lastIndex}`}>{code.substring(lastIndex, match.index)}</span>);
        }
        // Add the comment, styled
        parts.push(<span key={`comment-${match.index}`} className="text-green-400">{match[0]}</span>);
        lastIndex = commentRegex.lastIndex;
    }

    // Add any remaining text after the last comment
    if (lastIndex < code.length) {
        parts.push(<span key={`code-${lastIndex}`}>{code.substring(lastIndex)}</span>);
    }

    return <>{parts}</>;
};

const CodeDisplay: React.FC<{ code: string; language: string }> = ({ code, language }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = () => {
        navigator.clipboard.writeText(code);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="bg-gray-900 rounded-lg overflow-hidden relative group">
            <div className="flex justify-between items-center px-4 py-2 bg-black/25">
                <span className="text-xs font-semibold text-gray-400 uppercase">{language}</span>
                <button
                    onClick={handleCopy}
                    className="flex items-center space-x-1 text-xs text-gray-300 hover:text-white transition-colors"
                    aria-label="Copy code"
                >
                    {copied ? <CheckIcon className="h-4 w-4 text-green-400" /> : <CopyIcon className="h-4 w-4" />}
                    <span>{copied ? 'Copied!' : 'Copy'}</span>
                </button>
            </div>
            <pre className="p-4 text-sm text-white overflow-x-auto">
                <code>{highlightComments(code, language)}</code>
            </pre>
        </div>
    );
};

const TipsDisplay: React.FC<{ tips: Tip[] }> = ({ tips }) => (
    <div className="space-y-3">
        {tips.map((tip, index) => (
            <div key={index} className="flex items-start p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                <LightbulbIcon className="h-5 w-5 text-indigo-500 mr-3 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                    <p className="text-gray-800">{tip.text}</p>
                </div>
                <div className="relative group flex items-center ml-2">
                    <InfoIcon className="h-5 w-5 text-gray-400 cursor-pointer" />
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-64 p-2 bg-gray-800 text-white text-xs rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 z-10 pointer-events-none">
                        <span className="font-bold block">Simplified Tip:</span>
                        {tip.simplified}
                        <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-800"></div>
                    </div>
                </div>
            </div>
        ))}
    </div>
);

const ComplexityPanel: React.FC<{ analysis: AnalysisResult['complexity'] }> = ({ analysis }) => (
     <div className="p-6 bg-white rounded-lg border border-gray-200 space-y-4">
        <div>
            <h4 className="font-semibold text-lg text-gray-800 mb-2">Original Code Complexity</h4>
            <p className="text-gray-600">{analysis?.original}</p>
        </div>
        <div className="border-t border-gray-200 pt-4">
            <h4 className="font-semibold text-lg text-gray-800 mb-2">Refactored Code Complexity</h4>
            <p className="text-gray-600">{analysis?.refactored}</p>
        </div>
    </div>
);

const TabButton: React.FC<{ label: string; isActive: boolean; onClick: () => void }> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 ${
            isActive
                ? 'bg-indigo-600 text-white shadow'
                : 'text-gray-600 hover:bg-indigo-100'
        }`}
    >
        {label}
    </button>
);

const CodeVersionPanel: React.FC<{ version: CodeVersion; language: string; title: string }> = ({ version, language, title }) => (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
            <h4 className="font-semibold text-lg text-gray-800 mb-3">{title}</h4>
            <CodeDisplay code={version.code} language={language} />
        </div>
        <div>
            <h4 className="font-semibold text-lg text-gray-800 mb-3">Hints & Tips</h4>
            <TipsDisplay tips={version.tips} />
        </div>
    </div>
);

const ExplanationPanel: React.FC<{ version: CodeVersion; }> = ({ version }) => (
    <div>
        <h4 className="font-semibold text-lg text-gray-800 mb-3">Code Explanation</h4>
        <TipsDisplay tips={version.tips} />
    </div>
);

export const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ result, originalCode }) => {
    const [activeTab, setActiveTab] = useState<Tab | null>(null);

    const availableTabs = React.useMemo(() => {
        switch (result.type) {
            case 'analysis':
                return [Tab.Clean, Tab.Performant, Tab.Advanced, Tab.Complexity];
            case 'debug':
                return [Tab.Debug];
            case 'explanation':
                return [Tab.Explanation];
            default:
                return [];
        }
    }, [result.type]);

    useEffect(() => {
        if (availableTabs.length > 0) {
            setActiveTab(availableTabs[0]);
        }
    }, [availableTabs]);


    const renderContent = () => {
        if (!activeTab) return null;

        switch (activeTab) {
            case Tab.Clean:
                return result.cleanCode && <CodeVersionPanel version={result.cleanCode} language={originalCode.language} title="Refactored Code" />;
            case Tab.Performant:
                return result.performantCode && <CodeVersionPanel version={result.performantCode} language={originalCode.language} title="Refactored Code" />;
            case Tab.Advanced:
                return result.advancedCode && <CodeVersionPanel version={result.advancedCode} language={originalCode.language} title="Refactored Code" />;
            case Tab.Complexity:
                return result.complexity && <ComplexityPanel analysis={result.complexity} />;
            case Tab.Debug:
                 return result.cleanCode && <CodeVersionPanel version={result.cleanCode} language={originalCode.language} title="Corrected Code" />;
            case Tab.Explanation:
                return result.cleanCode && <ExplanationPanel version={result.cleanCode} />;
            default:
                return null;
        }
    };

    return (
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
            <div className="mb-6 border-b border-gray-200 pb-4">
                <div className="flex flex-wrap items-center gap-2">
                    {availableTabs.map((tab) => (
                        <TabButton
                            key={tab}
                            label={tab}
                            isActive={activeTab === tab}
                            onClick={() => setActiveTab(tab)}
                        />
                    ))}
                </div>
            </div>
            <div>{renderContent()}</div>
        </div>
    );
};