
import React from 'react';
import { SpinnerIcon } from './Icons';
import { Action } from '../services/geminiService';

interface LoaderProps {
    action: Action;
}

const getActionText = (action: Action) => {
    switch (action) {
        case 'analyze': return 'Analyzing your code...';
        case 'debug': return 'Debugging your code...';
        case 'explain': return 'Generating an explanation...';
        default: return 'Processing...';
    }
}

export const Loader: React.FC<LoaderProps> = ({ action }) => (
    <div className="flex flex-col items-center justify-center text-center mt-12">
        <SpinnerIcon className="h-12 w-12 text-indigo-500 animate-spin" />
        <p className="mt-4 text-lg font-semibold text-gray-700">{getActionText(action)}</p>
        <p className="text-gray-500">This may take a few moments.</p>
    </div>
);